# Release Instructions

To publish a new release of GS Model Helper:

1. Update the version number in both:
   - `blender_manifest.toml`
   - `bl_info` inside `__init__.py`

2. Commit and push your changes.

3. Create a new git tag for the release, e.g.:
   ```bash
   git tag -a v2.2.0 -m "Release v2.2.0"
   git push origin v2.2.0
   ```

4. Create a GitHub Release:
   - Go to the repository's "Releases" tab.
   - Click "Draft a new release".
   - Select the tag you created.
   - Upload the `goldsrc_model_helper.zip` from the addon folder.
   - Publish the release.

5. (Optional) Submit the new release to Blender's Extensions Platform.

