# Contributing to GS Model Helper

Thanks for your interest in contributing!

## How to Contribute
1. Fork the repository and create your branch from `main`.
2. Make your changes and ensure the addon still installs and works in Blender.
3. Submit a pull request with a clear description of your changes.

## Guidelines
- Follow Blender's Python API conventions.
- Keep code clean, documented, and organized.
- Test your changes in Blender before submitting.

---
Maintained by **DaKashi**.
